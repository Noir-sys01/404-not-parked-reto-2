// OCR local: busca patrones de placas colombianas; no es un detector YOLO.
let cargaOCR;
function cargarOCR(){
 if(window.Tesseract)return Promise.resolve();
 if(!cargaOCR)cargaOCR=new Promise((resolve,reject)=>{
  const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';s.onload=resolve;s.onerror=()=>{cargaOCR=null;s.remove();reject(new Error('OCR no disponible'));};document.head.append(s);
 });return cargaOCR;
}
async function detectarPlacas(canvas){
 await cargarOCR();
 const worker=await Tesseract.createWorker('eng',1);
 try{
  await worker.setParameters({tessedit_pageseg_mode:'11'});
  const {data}=await worker.recognize(canvas);
  const resultado=[];
  const patron=/^[A-Z]{3}[0-9]{2}[0-9A-Z]$/;
  for(const line of data.lines||[]){
   const words=line.words||[];
   for(let i=0;i<words.length;i++)for(let n=1;n<=3&&i+n<=words.length;n++){
    const grupo=words.slice(i,i+n);const texto=grupo.map(w=>w.text).join('').toUpperCase().replace(/[^A-Z0-9]/g,'');
    if(!patron.test(texto))continue;
    const b=grupo.map(w=>w.bbox);const x0=Math.min(...b.map(v=>v.x0)),y0=Math.min(...b.map(v=>v.y0)),x1=Math.max(...b.map(v=>v.x1)),y1=Math.max(...b.map(v=>v.y1));
    const margen=Math.max(8,(y1-y0)*0.65);const x=Math.max(0,x0-margen),y=Math.max(0,y0-margen);
    resultado.push({x,y,w:Math.min(canvas.width,x1+margen)-x,h:Math.min(canvas.height,y1+margen)-y});
   }
  }
  return resultado;
 }finally{await worker.terminate();}
}
