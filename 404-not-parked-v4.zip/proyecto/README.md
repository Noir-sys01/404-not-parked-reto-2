# Nombre del equipo - Reto 2

Control de mal parqueo e invasión del espacio público (zona universitaria, Santa Marta).

## Integrantes y roles
| Integrante | Rol |
|---|---|
| (nombre) | (rol) |

## Prototipo publicado
(enlace de GitHub Pages)

## Cómo abrirlo
1. Abrir la carpeta en VS Code.
2. Clic derecho en `index.html` > "Open with Live Server".

## IA utilizada
(Claude, y para qué partes del proyecto)

## Interfaz 404-not-parked
Abrir con Live Server. Las vistas Inicio, Ciudadano y Supervisor son demostrativas. Los reportes nuevos se guardan únicamente en localStorage y quedan sin evaluar; no existe autenticación ni servidor. Los filtros y estadísticas se calculan sobre los registros visibles. Leaflet y el mapa requieren internet. Se conservan los JSON originales y sus advertencias de datos provisionales.

### Evidencia fotográfica
Adjunto opcional JPG, PNG o WEBP de hasta 5 MB, reducido a JPEG de máximo 1000 px. Se guarda localmente con el reporte y aparece en el detalle del supervisor al seleccionar una fila o marcador. No se comparte entre dispositivos ni se sube a un servidor.

## Privacidad de fotografías
Censura manual: arrastra sobre placas y rostros, revisa y confirma antes de guardar. No hay detección automática. Solo se guarda el JPEG editado para nuevos reportes. Las fotos antiguas sin confirmación no se muestran al supervisor; pueden permanecer en el almacenamiento local de versiones anteriores.

## V4 — censura automática experimental
Usa Tesseract.js 5.1.1 (OCR en el navegador), descargado desde CDN, para localizar texto con formato de placa colombiana de automóvil o motocicleta. No incluye un modelo YOLO entrenado. Requiere internet para cargar las dependencias y puede omitir placas borrosas, inclinadas o de otros formatos. La foto no se envía a un servicio OCR. Revisa y cubre manualmente todas las placas y rostros antes de guardar. Solo se persiste la imagen editada. No se ha validado la precisión con fotografías reales.
