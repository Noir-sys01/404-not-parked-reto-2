# Nombre del equipo - Reto 2

Control de mal parqueo e invasión del espacio público (zona universitaria, Santa Marta).

## Integrantes y roles
| Integrante | Rol |
|---|---|
| (nombre) | (rol) |

## Prototipo publicado
(enlace de GitHub Pages)

## Cómo abrirlo
1. Abrir la carpeta en VS Code.
2. Clic derecho en `index.html` > "Open with Live Server".

## IA utilizada
(Claude, y para qué partes del proyecto)

## Interfaz 404-not-parked
Abrir con Live Server. Las vistas Inicio, Ciudadano y Supervisor son demostrativas. Los reportes nuevos se guardan únicamente en localStorage y quedan sin evaluar; no existe autenticación ni servidor. Los filtros y estadísticas se calculan sobre los registros visibles. Leaflet y el mapa requieren internet. Se conservan los JSON originales y sus advertencias de datos provisionales.
